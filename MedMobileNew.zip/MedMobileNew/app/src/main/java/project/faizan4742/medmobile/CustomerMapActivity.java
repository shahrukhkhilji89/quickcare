package project.faizan4742.medmobile;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.HandlerThread;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;

import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.Clock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class CustomerMapActivity extends FragmentActivity implements OnMapReadyCallback {
    private static final String TAG = "CustomerMapActivity";
    private GoogleMap mMap;
    Location mLastLocation;
    LocationRequest mLocationRequest;
    LocationObject destinationLocation;
    HandlerThread mHandlerThread;

    private FusedLocationProviderClient mFusedLocationClient;


    private Button mLogout,mRequest,mSettings,mHistory;
    private LatLng pickupLocation;
    private Boolean requestBol = false;
    private Marker pickupMarker;

    private SupportMapFragment mapFragment;

    private String destination;

    private LatLng destinationLatlng;

    private RatingBar mRatingBar;

    private LinearLayout mDriverInfo;
    Button searchPlace;

    private TextView mDriverName, mDriverPhone, mDriverCar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_map);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        destinationLatlng = new LatLng(0.0, 0.0);

        mDriverInfo = (LinearLayout) findViewById(R.id.driverInfo);

        mDriverName = (TextView) findViewById(R.id.driverName);
        mDriverPhone = (TextView) findViewById(R.id.driverPhone);
        mDriverCar = (TextView) findViewById(R.id.driverCar);

        mRequest = (Button) findViewById(R.id.request);
        mSettings = (Button) findViewById(R.id.settings);
        mRatingBar = (RatingBar) findViewById(R.id.ratingBar);
        mHistory = (Button) findViewById(R.id.history);
        mLogout = (Button) findViewById(R.id.logout);
        searchPlace = findViewById(R.id.searchPlace);



        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(CustomerMapActivity.this, Welcome_Activity.class);
                startActivity(intent);
                finish();
                return;
            }

        });

        mSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(CustomerMapActivity.this,CustomerSettingsActivity.class);
                startActivity(intent);
            }

        });


        mHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CustomerMapActivity.this,HistoryActivity.class);
                intent.putExtra("customerOrDriver","Customers");
                startActivity(intent);

            }
        });





        //AUTO COMPLETE PLACES
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyAmYjVSQKUTVBdqYIcEJOjhg5Sh7xDWU3o");
        }

        searchPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onCreate: Button Pressed hahhahhahahhahahhahhahahhahahahhahhahahha");
                searchPlace.setVisibility(View.GONE);
                Intent intent = new Autocomplete.IntentBuilder(
                        AutocompleteActivityMode.OVERLAY, Arrays.asList(com.google.android.libraries.places.api.model.Place.Field.ID, com.google.android.libraries.places.api.model.Place.Field.NAME, Place.Field.LAT_LNG))
                        .build(getApplicationContext());
                Log.d(TAG, "initPlacesAutocomplete: Pressed For Fragment Results");
                startActivityForResult(intent, 1);
            }
        });
    }

    public void requestingForDriver(View view){
        Runnable requestingForDriverRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "run: Requesting For Driver In " + Thread.currentThread().getName());
                if(requestBol){
                    endRide();
                }
                requestBol = true;
                String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();

                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("customerRequest");
                GeoFire geoFirePickupLoc = new GeoFire(ref);
//                GeoFire geoFireDestinationLoc = new GeoFire(ref.child("destinationLocation"));

                geoFirePickupLoc.setLocation(userId, new GeoLocation(mLastLocation.getLatitude(),mLastLocation.getLongitude()));
//                geoFireDestinationLoc.setLocation(userId, new GeoLocation(destinationLatlng.latitude, destinationLatlng.longitude));

                pickupLocation = new LatLng(mLastLocation.getLatitude(),mLastLocation.getLongitude());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pickupMarker = mMap.addMarker(new MarkerOptions().position(pickupLocation).title("Pickup Here").icon(BitmapDescriptorFactory.fromResource(R.mipmap.patient)));
                        mRequest.setText("Getting Your Ambulance...");
                    }
                });

                getClosestDriver();
            }
        };
        Thread thread = new Thread(requestingForDriverRunnable);
        thread.start();

    }

    /**
     * Override the activity's onActivityResult(), check the request code, and
     * do something with the returned place data (in this example it's place name and place ID).
     */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult: hahhahhahahhahahhahhahahhahahhahhahahhaha");
        if (resultCode == RESULT_OK) {
            LocationObject mLocation;
            Place place = Autocomplete.getPlaceFromIntent(data);

            mLocation = new LocationObject(place.getLatLng(), place.getName());

            if (requestCode == 1) {
                searchPlace.setVisibility(View.VISIBLE);
                destinationLocation = mLocation;
                destination = destinationLocation.getName();
                destinationLatlng = destinationLocation.getCoordinates();
                mRequest.setText("Request For: " + destinationLocation.getName());
                Log.d(TAG, "onActivityResult: Latitude: " + destinationLatlng.latitude + " Longitude: " + destinationLatlng.longitude + " Location Name: " + destinationLocation.getName());

            }



        } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
            // TODO: Handle the error.
            Status status = Autocomplete.getStatusFromIntent(data);
            assert status.getStatusMessage() != null;
            Log.i("PLACE_AUTOCOMPLETE", status.getStatusMessage());
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid != null){
            DatabaseReference root = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(uid);
            root.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.child("Name").exists()){
                        Toast.makeText(CustomerMapActivity.this, "Welcome " + snapshot.child("Name").getValue(String.class) + " to MedMobile" , Toast.LENGTH_LONG).show();
                    }else{
                        new AlertDialog.Builder(CustomerMapActivity.this)
                                .setTitle("Profile")
                                .setMessage("Kindly setup your profile first.")
                                .setPositiveButton("Setup", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        startActivity(new Intent(CustomerMapActivity.this, CustomerSettingsActivity.class));
                                    }
                                })
                                .setNegativeButton("Not now", null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }
    }

    private int radius=1;
    private Boolean driverFound = false;
    private String driverFoundID;
    GeoQuery geoQuery;


    // TODO: 8/2/2022 Do In Background

    private void getClosestDriver(){
        Runnable getDriverInBackground = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "run: This Methode Getting Closest Driver In " + Thread.currentThread().getName());
                DatabaseReference driverLocation = FirebaseDatabase.getInstance().getReference().child("driversAvailable");

                GeoFire geoFire = new GeoFire(driverLocation);
                geoQuery = geoFire.queryAtLocation(new GeoLocation(pickupLocation.latitude, pickupLocation.longitude), radius);
                geoQuery.removeAllListeners();

                geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
                    @Override
                    public void onKeyEntered(String key, GeoLocation location) {
                        if (!driverFound && requestBol){
                            DatabaseReference mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(key);
                            mCustomerDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0){
                                        if (driverFound){
                                            return;
                                        }


                                        driverFound = true;
                                        driverFoundID = dataSnapshot.getKey();

                                        DatabaseReference driverRef = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(driverFoundID).child("customerRequest");
                                        String customerId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                        HashMap map = new HashMap();
                                        map.put("customerRideId", customerId);
                                        map.put("destination", destination);
                                        map.put("destinationLat", destinationLatlng.latitude);
                                        map.put("destinationLng", destinationLatlng.longitude);
                                        driverRef.updateChildren(map);



                                        getDriverLocation();
                                        getDriverInfo();
                                        getHasRideEnded();
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                mRequest.setText("Looking for Driver's Location....");

                                            }
                                        });

                                    }

                                }
                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                }
                            });
                        }
                    }

                    @Override
                    public void onKeyExited(String key) {

                    }

                    @Override
                    public void onKeyMoved(String key, GeoLocation location) {

                    }

                    @Override
                    public void onGeoQueryReady() {
                        if (!driverFound)
                        {
                            radius++;
                            getClosestDriver();
                        }
                    }

                    @Override
                    public void onGeoQueryError(DatabaseError error) {

                    }
                });
            }
        };
        Thread thread = new Thread(getDriverInBackground);
        thread.start();


    }

    private Marker mDriverMarker;
    private DatabaseReference driverLocationRef;
    private ValueEventListener driverLocationRefListener;
    private void getDriverLocation(){
        Runnable getDriverLocationRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "getDriverLocation: Driver Location Getting In " + Thread.currentThread().getName());
                driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversWorking").child(driverFoundID).child("l");
                driverLocationRefListener=driverLocationRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists() && requestBol){
                            List<Object> map=(List<Object>) dataSnapshot.getValue();
                            double LocationLat = 0;
                            double LocationLng = 0;
                            // mRequest.setText("Ambulance Found");
                            if(map.get(0)!= null){
                                LocationLat = Double.parseDouble(map.get(0).toString());
                            }
                            if(map.get(1)!= null){
                                LocationLng = Double.parseDouble(map.get(1).toString());
                            }
                            LatLng driverLatLng = new LatLng(LocationLat, LocationLng);
                            if(mDriverMarker!=null){
                                mDriverMarker.remove();
                            }
                            Location loc1 = new Location("");
                            loc1.setLatitude(pickupLocation.latitude);
                            loc1.setLongitude(pickupLocation.longitude);

                            Location loc2 = new Location("");
                            loc2.setLatitude(driverLatLng.latitude);
                            loc2.setLongitude(driverLatLng.longitude);

                            float distance = loc1.distanceTo(loc2);
                            if(distance<100){
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mRequest.setText("Ambulance Arrived");
                                    }
                                });

                            }else{
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        int dis = (int)distance/1000;
                                        mRequest.setText("Ambulance Found: "+ String.valueOf(dis)+ " Kms away...");
                                    }
                                });

                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mDriverMarker = mMap.addMarker(new MarkerOptions().position(driverLatLng).title("Your Ambulance").icon(BitmapDescriptorFactory.fromResource(R.mipmap.ambulance)));
                                }
                            });

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        };
        Thread thread = new Thread(getDriverLocationRunnable);
        thread.start();

    }


    private void getDriverInfo(){
                mDriverInfo.setVisibility(View.VISIBLE);
        Runnable getDriverInfoRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "getDriverInfo: Driver Info Getting In " + Thread.currentThread().getName());

                DatabaseReference mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(driverFoundID);
                mCustomerDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists() && dataSnapshot.getChildrenCount() > 0) {
                            if (dataSnapshot.child("Name").getValue(String.class) != null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mDriverName.setText(dataSnapshot.child("Name").getValue(String.class));
                                    }
                                });

                            }
                            if (dataSnapshot.child("Phone").getValue(String.class) != null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mDriverPhone.setText(dataSnapshot.child("Phone").getValue(String.class));
                                    }
                                });

                            }
                            if (dataSnapshot.child("Car").getValue(String.class) != null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mDriverCar.setText(dataSnapshot.child("Car").getValue(String.class));
                                    }
                                });

                            }

                            int ratingSum = 0;
                            float ratingsTotal = 0;
                            float ratingsAvg = 0;
                            for (DataSnapshot child : dataSnapshot.child("rating").getChildren()) {
                                ratingSum = ratingSum + Integer.valueOf(child.getValue().toString());
                                ratingsTotal++;
                            }
                            if (ratingsTotal != 0) {
                                ratingsAvg = ratingSum / ratingsTotal;
                                float finalRatingsAvg = ratingsAvg;
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mRatingBar.setRating(finalRatingsAvg);
                                        Log.d("BarSetting", "onDataChange: Sleep After Setting Values To Views");
                                    }
                                });
                            }
                            Log.d("SettingView", "onDataChange: Sleep After Setting Values To Views");
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (mDriverInfo.getVisibility() == View.VISIBLE) {
                                        mDriverInfo.setVisibility(View.GONE);
                                    }
                                }
                            });
                        }
                        Log.d("AfterElse", "onDataChange: Sleep After Setting Values To Views");
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }
        };

        Thread thread = new Thread(getDriverInfoRunnable);
        thread.start();
        Log.d("AfterThread", "getDriverInfo: Sleep After Getting the Driver Info");

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);


        if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            }else{
                checkLocationPermission();
            }
        }

        mHandlerThread = new HandlerThread("Location Call Back Thread");
        mHandlerThread.start();



        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, mHandlerThread.getLooper());

        mMap.setMyLocationEnabled(true);
    }

    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Log.d(TAG, "onLocationResult: This is in " + Thread.currentThread().getName());
            for (Location location : locationResult.getLocations()) {

                mLastLocation = location;

                LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());


                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                        mMap.animateCamera(CameraUpdateFactory.zoomTo(11));
                    }
                });

                if(!getDriversAroundStarted) {
                    Log.d(TAG, "onLocationResult: This If Statement In " + Thread.currentThread().getName());
                    getDriversAround();
                }

            }
        }

    };


    boolean getDriversAroundStarted = false;
    List<Marker> markers = new ArrayList<Marker>();
    private void getDriversAround(){
                Log.d("RunningIn", "getDriversAround: Drivers Getting Around In === " + Thread.currentThread().getName());
                getDriversAroundStarted = true;
                DatabaseReference driverLocation = FirebaseDatabase.getInstance().getReference().child("driversAvailable");

                GeoFire geoFire = new GeoFire(driverLocation);
                GeoQuery geoQuery = geoFire.queryAtLocation(new GeoLocation(mLastLocation.getLongitude(), mLastLocation.getLatitude()), 999999999);

                geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
                    @Override
                    public void onKeyEntered(String key, GeoLocation location) {
                        LatLng driverLocation = new LatLng(location.latitude, location.longitude);

                        Marker mDriverMarker = mMap.addMarker(new MarkerOptions().position(driverLocation).title(key).icon(BitmapDescriptorFactory.fromResource(R.mipmap.ambulance)));
                        mDriverMarker.setTag(key);

                        markers.add(mDriverMarker);

                        for(Marker markerIt : markers) {
                            if (markerIt != null && key != null && markerIt.getTag() != null) {
                                if (markerIt.getTag().equals(key))
                                    Log.d(TAG, "onKeyEntered: Entered ---------------------------------------------haha");
                                return;
                            }
                        }
                    }

                    @Override
                    public void onKeyExited(String key) {
                        for(Marker markerIt : markers){
                            if (markerIt != null && key != null){
                                if(Objects.equals(markerIt.getTag(), key)){
                                    Log.d(TAG, "onKeyExited: Exited --------------------------- haha");

                                            markerIt.remove();


                                }
                            }
                        }
                    }

                    @Override
                    public void onKeyMoved(String key, GeoLocation location) {
                        for(Marker markerIt : markers){
                            if(markerIt != null && key != null && markerIt.getTag() != null){
                                if(markerIt.getTag().equals(key)){
                                    Log.d(TAG, "onKeyMoved: KeyMoved ---------------------- haha");

                                    markerIt.setPosition(new LatLng(location.latitude, location.longitude));


                                }
                            }
                        }
                    }

                    @Override
                    public void onGeoQueryReady() {
                    }

                    @Override
                    public void onGeoQueryError(DatabaseError error) {

                    }
                });
            }



    private void checkLocationPermission() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)){
                new  android.app.AlertDialog.Builder(this)
                        .setTitle("Please give permission...")
                        .setMessage("Please give permission...")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(CustomerMapActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                            }
                        })
                        .create()
                        .show();
            }
            else{
                ActivityCompat.requestPermissions(CustomerMapActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);

            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
                        mFusedLocationClient.requestLocationUpdates(mLocationRequest,mLocationCallback, Looper.myLooper());
                        mMap.setMyLocationEnabled(true);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please provide the permission...", Toast.LENGTH_LONG).show();
                }
                break;
            }


        }}

        private DatabaseReference driveHasEndedRef;
    private ValueEventListener driveHasEndedRefListener;
    private void getHasRideEnded(){
       // String driverId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        driveHasEndedRef  = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(driverFoundID).child("customerRequest").child("customerRideId");
        driveHasEndedRefListener = driveHasEndedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    Log.d("GettingSnapShot", "onDataChange: It is getting some data" + dataSnapshot.getKey());
                }else{
                    Log.d("GettingSnapShot", "onDataChange: It is getting nothing");
                    endRide();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        Log.d("EndOfMethodeHasEnded", "onDataChange: Running");

    }
    private void endRide()
    {
Runnable endRideRunnable = new Runnable() {
    @Override
    public void run() {
        requestBol = false;
        if(geoQuery != null){
            geoQuery.removeAllListeners();
        }
        if(driverLocationRefListener != null&& driveHasEndedRefListener != null){
            driverLocationRef.removeEventListener(driverLocationRefListener);
            driveHasEndedRef.removeEventListener(driveHasEndedRefListener);
        }
        if(driverFoundID!=null){
            DatabaseReference driverRef = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(driverFoundID).child("customerRequest");
            driverRef.removeValue();
            driverFoundID = null;
        }
        driverFound = false;
        radius = 1;

        String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("customerRequest");
        GeoFire geoFire = new GeoFire(ref);
        geoFire.removeLocation(userId);
        if( pickupMarker!=null){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pickupMarker.remove();
                }
            });

        }
        if (mDriverMarker != null){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mDriverMarker.remove();
                }
            });

        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mRequest.setText("Request An Ambulance");

                mDriverInfo.setVisibility(View.GONE);
                mDriverName.setText("");
                mDriverPhone.setText("");
            }
        });
    }
};
Thread thread = new Thread(endRideRunnable);
thread.start();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mHandlerThread.quit();
    }
}