package project.faizan4742.medmobile;

import android.content.Intent;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Welcome_Activity extends AppCompatActivity {
    private static final String TAG = "Welcome_Activity";
    RelativeLayout rellay1, rellay2;
    private Button mdriver, mCustomer;
    FirebaseAuth mAuth;
    DatabaseReference root;

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            Log.d(TAG, "run: Running");
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_);
        mAuth = FirebaseAuth.getInstance();
        root = FirebaseDatabase.getInstance().getReference().child("Users");


        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        rellay2 = (RelativeLayout) findViewById(R.id.rellay2);

        startService(new Intent(Welcome_Activity.this,onAppKilled.class));
        Log.d(TAG, "onCreate: Service Started");
        handler.postDelayed(runnable, 1000); //2000 is the timeout for the splash




    }
    @Override
    protected void onStart() {
        super.onStart();
        if(mAuth.getCurrentUser() != null){
            String uid = FirebaseAuth.getInstance().getUid();
            if (uid != null){
                root.child("Drivers").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()){
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                Log.d(TAG, "onDataChange: Datasnapshot: " + ds.getKey());
                                if (ds.getKey().equals(uid)){
                                    startActivity(new Intent(Welcome_Activity.this, DriverMapActivity.class));
                                    finish();
                                }else{
                                    startActivity(new Intent(Welcome_Activity.this, CustomerMapActivity.class));
                                    finish();
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        }
    }

    public void driver(View v) {
        Toast.makeText(this,"I am a driver",Toast.LENGTH_SHORT).show();
    }

    public void patient(View v) {
        Toast.makeText(this,"I am a Patient",Toast.LENGTH_SHORT).show();
    }

    public void sendMessage(View view)
    {
        Intent intent = new Intent(Welcome_Activity.this, CustomerLoginActivity.class);
        Log.d(TAG, "sendMessage: Customer");
        startActivity(intent);
    }
    public void sendMessage2(View view)
    {
        Intent intent = new Intent(Welcome_Activity.this, DriverLoginActivity.class);
        Log.d(TAG, "sendMessage2: Driver");
        startActivity(intent);
    }
    }
